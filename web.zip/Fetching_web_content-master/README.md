This project downloads an Image from the internet in the android Application
